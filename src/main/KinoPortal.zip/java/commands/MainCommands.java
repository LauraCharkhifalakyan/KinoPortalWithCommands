package commands;

public interface MainCommands {
    int EXIT = 0;
    int ALLMOVIES = 1;
    int ALLGENRES = 2;
    int MOVIESBYGENRE = 3;
    int MOVIESBYYEAR = 4;
    int ADDGENRE = 5;
    int ADDMOVIE = 6;

}
